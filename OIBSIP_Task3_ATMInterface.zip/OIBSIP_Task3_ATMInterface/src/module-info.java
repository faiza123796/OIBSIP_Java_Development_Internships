/**
 * 
 */
/**
 * 
 */
module OIBSIP_Task3_ATMInterface {
}