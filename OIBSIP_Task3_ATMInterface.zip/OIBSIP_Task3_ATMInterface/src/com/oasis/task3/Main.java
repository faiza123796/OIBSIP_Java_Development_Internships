package com.oasis.task3;

public class Main {

	public static void main(String[] args) {
		Bank bank = new Bank();

		Account account1 = new Account("user1", "1234", 10000);
		Account account2 = new Account("user2", "5678", 5000);

		bank.addAccount(account1);
		bank.addAccount(account2);
		ATM atm = new ATM(bank);

		Account loggedInAccount = atm.login();

		if (loggedInAccount != null) {
		    atm.showMenu(loggedInAccount);
		}
		

	}

}
