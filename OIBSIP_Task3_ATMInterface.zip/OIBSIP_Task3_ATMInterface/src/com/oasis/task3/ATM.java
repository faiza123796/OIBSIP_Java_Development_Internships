package com.oasis.task3;
import java.util.ArrayList;
import java.util.Scanner;

public class ATM {
	private Bank bank;
	private ArrayList<Transaction> transactions;
	private Scanner scanner;
	 public ATM(Bank bank) {
	        this.bank = bank;
	        this.transactions = new ArrayList<>();
	        this.scanner = new Scanner(System.in);
	    }
	 public Account login() {

		    int attempts = 0;

		    while (attempts < 3) {

		        System.out.print("Enter User ID: ");
		        String userId = scanner.nextLine();

		        System.out.print("Enter PIN: ");
		        String pin = scanner.nextLine();

		        Account account = bank.getAccount(userId);

		        if (account != null && account.getPin().equals(pin)) {
		            System.out.println("Login Successful!");
		            return account;
		        } else {
		            attempts++;
		            System.out.println("Invalid User ID or PIN!");
		            System.out.println("Attempts remaining: " + (3 - attempts));
		        }
		    }

		    System.out.println("Too many incorrect attempts. Access Denied!");
		    return null;
		}
	 
	 public void showMenu(Account account) {

		    boolean running = true;
		    
		    while (running) {

		        System.out.println("\n===== ATM MENU =====");
		        System.out.println("1. Transaction History");
		        System.out.println("2. Withdraw");
		        System.out.println("3. Deposit");
		        System.out.println("4. Transfer");
		        System.out.println("5. Quit");

		        System.out.print("Choose an option: ");
		        int choice = scanner.nextInt();
		        scanner.nextLine();
		        switch (choice) {
		
		      

		       

		        case 1:
		            showTransactionHistory();
		            break;

		        case 2:
		            withdraw(account);
		            break;

		        case 3:
		            deposit(account);
		            break;

		        case 4:
		            transfer(account);
		            break;

		        case 5:
		            System.out.println("Thank you for using the ATM!");
		            running = false;
		            break;

		        default:
		            System.out.println("Invalid option!");
		    }
		        }
		    }
		    

		    public void deposit(Account account) {

		        System.out.print("Enter amount to deposit: ");
		        double amount = scanner.nextDouble();
		        scanner.nextLine();

		        if (amount > 0) {
		            account.deposit(amount);
		            transactions.add(new Transaction("Deposit", amount));
		            System.out.println("Deposit successful!");
		            System.out.println("Current Balance: ₹" + account.getBalance());
		        } else {
		            System.out.println("Invalid amount!");
		        }
		    }
		    public void withdraw(Account account) {
		        System.out.print("Enter amount to withdraw: ");
		        double amount = scanner.nextDouble();
		        scanner.nextLine();

		        if (amount > 0 && account.withdraw(amount)) {
		            transactions.add(new Transaction("Withdraw", amount));
		            System.out.println("Withdrawal successful!");
		            System.out.println("Current Balance: ₹" + account.getBalance());
		        } else {
		            System.out.println("Insufficient Funds or Invalid Amount!");
		        }
		    }
		    public void showTransactionHistory() {

		        System.out.println("\n===== TRANSACTION HISTORY =====");

		        if (transactions.isEmpty()) {
		            System.out.println("No transactions yet.");
		        } else {
		            for (Transaction transaction : transactions) {
		                System.out.println(transaction);
		            }
		        }
		    }
		    public void transfer(Account sender) {

		        System.out.print("Enter recipient User ID: ");
		        String recipientId = scanner.nextLine();

		        Account recipient = bank.getAccount(recipientId);

		        if (recipient == null) {
		            System.out.println("Recipient account not found!");
		            return;
		        }

		        System.out.print("Enter amount to transfer: ");
		        double amount = scanner.nextDouble();
		        scanner.nextLine();

		        if (amount > 0 && sender.withdraw(amount)) {

		            recipient.deposit(amount);

		            transactions.add(new Transaction(
		                "Transfer to " + recipientId, amount));

		            System.out.println("Transfer successful!");
		            System.out.println("Current Balance: ₹" + sender.getBalance());

		        } else {
		            System.out.println("Insufficient Funds or Invalid Amount!");
		        }
		    }
		

}
