package com.oasis.task2;
import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		int round = 1;
		boolean playAgain = true;
		System.out.println("WELCOME TO NUMBER GUESSING GAME");
		while (playAgain) {
			
			int randomNumber = random.nextInt(100) + 1;
			int maxAttempts = 7;
			int attempts = 0;
			boolean guessedCorrectly = false;
			System.out.println("\nROUND " + round);
			System.out.println("Guess a number between 1 and 100.");
			System.out.println("You have 7 attempts.");
			while (attempts < maxAttempts) {
				System.out.print("Enter your guess: ");
				if (!scanner.hasNextInt()) {
				    System.out.println("Please enter a valid number!");
				    scanner.next();
				    continue;
				}
				int guess = scanner.nextInt();
				attempts++;
				if (guess > randomNumber) {
				    System.out.println("Too High!");
				} else if (guess < randomNumber) {
				    System.out.println("Too Low!");
				} else {
				    System.out.println("Correct!");
				    System.out.println("You guessed it in " + attempts + " attempts.");
				    guessedCorrectly = true;
				    break;
				}
				System.out.println("Attempts remaining: " + (maxAttempts - attempts));

			}
			if (!guessedCorrectly) {
			    System.out.println("You Lost!");
			    System.out.println("The correct number was: " + randomNumber);
			}
			System.out.print("Do you want to play again? (yes/no): ");
			String choice = scanner.next().toLowerCase();
			

	
		if (choice.equals("yes")) {
		    round++;
		} else {
		    playAgain = false;
		    System.out.println("Thank you for playing!");
		}
		scanner.close();

	}
	}

}
